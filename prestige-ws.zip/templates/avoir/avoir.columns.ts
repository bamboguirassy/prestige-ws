export const avoirColumns = [
            { header: 'Date', field: 'date', dataKey: 'date' },
            { header: 'Montant', field: 'montant', dataKey: 'montant' },
            { header: 'Utilise', field: 'utilise', dataKey: 'utilise' },
        ];

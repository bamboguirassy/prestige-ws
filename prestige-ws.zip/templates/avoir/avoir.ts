import { BamboObject } from 'src/app/shared/interfaces/bambo-object';

export class Avoir extends BamboObject {
    id: any;
                                date: string;
                                        montant: string;
                                        utilise: string;
                        
    constructor() {
        super();
    }
}

export const modeleColumns = [
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'Description', field: 'description', dataKey: 'description' },
            { header: 'Photo', field: 'photo', dataKey: 'photo' },
        ];

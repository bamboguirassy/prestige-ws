export const venteProduitColumns = [
            { header: 'PrixUnitaire', field: 'prixUnitaire', dataKey: 'prixUnitaire' },
            { header: 'Quantite', field: 'quantite', dataKey: 'quantite' },
            { header: 'MontantTotal', field: 'montantTotal', dataKey: 'montantTotal' },
        ];

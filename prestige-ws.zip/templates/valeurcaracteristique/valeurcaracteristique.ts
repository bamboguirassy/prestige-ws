import { BamboObject } from 'src/app/shared/interfaces/bambo-object';

export class ValeurCaracteristique extends BamboObject {
    id: any;
                                valeur: string;
                                        color: string;
                        
    constructor() {
        super();
    }
}

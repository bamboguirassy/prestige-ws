export const valeurCaracteristiqueColumns = [
            { header: 'Valeur', field: 'valeur', dataKey: 'valeur' },
            { header: 'Color', field: 'color', dataKey: 'color' },
        ];

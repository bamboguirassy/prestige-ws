export class User {
    id: any;
                        username: string;
                                        usernameCanonical: string;
                                        email: string;
                                        emailCanonical: string;
                                        enabled: string;
                                        salt: string;
                                        password: string;
                                        lastLogin: string;
                                        confirmationToken: string;
                                        passwordRequestedAt: string;
                                        roles: string;
                                                prenom: string;
                                        nom: string;
                                        telephone: string;
                    }

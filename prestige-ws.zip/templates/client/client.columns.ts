export const clientColumns = [
            { header: 'Prenom', field: 'prenom', dataKey: 'prenom' },
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'Telephone', field: 'telephone', dataKey: 'telephone' },
            { header: 'Email', field: 'email', dataKey: 'email' },
            { header: 'Fonction', field: 'fonction', dataKey: 'fonction' },
            { header: 'Adresse', field: 'adresse', dataKey: 'adresse' },
        ];

export const venteColumns = [
            { header: 'MontantInitial', field: 'montantInitial', dataKey: 'montantInitial' },
            { header: 'MontantRegle', field: 'montantRegle', dataKey: 'montantRegle' },
            { header: 'MontantRestant', field: 'montantRestant', dataKey: 'montantRestant' },
            { header: 'DateLivraison', field: 'dateLivraison', dataKey: 'dateLivraison' },
            { header: 'AdresseLivraison', field: 'adresseLivraison', dataKey: 'adresseLivraison' },
            { header: 'Livree', field: 'livree', dataKey: 'livree' },
            { header: 'Regle', field: 'regle', dataKey: 'regle' },
            { header: 'DateLivraisonPrevue', field: 'dateLivraisonPrevue', dataKey: 'dateLivraisonPrevue' },
            { header: 'DateLivraisonEffective', field: 'dateLivraisonEffective', dataKey: 'dateLivraisonEffective' },
            { header: 'Type', field: 'type', dataKey: 'type' },
            { header: 'Date', field: 'date', dataKey: 'date' },
            { header: 'NumeroVente', field: 'numeroVente', dataKey: 'numeroVente' },
        ];

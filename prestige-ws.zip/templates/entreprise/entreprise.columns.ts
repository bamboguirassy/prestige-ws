export const entrepriseColumns = [
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'Telephone', field: 'telephone', dataKey: 'telephone' },
            { header: 'Ninea', field: 'ninea', dataKey: 'ninea' },
            { header: 'Email', field: 'email', dataKey: 'email' },
            { header: 'Adresse', field: 'adresse', dataKey: 'adresse' },
            { header: 'NomPrenomPatron', field: 'nomPrenomPatron', dataKey: 'nomPrenomPatron' },
            { header: 'Gerant', field: 'gerant', dataKey: 'gerant' },
            { header: 'TelephoneGerant', field: 'telephoneGerant', dataKey: 'telephoneGerant' },
            { header: 'TelephonePatron', field: 'telephonePatron', dataKey: 'telephonePatron' },
            { header: 'Description', field: 'description', dataKey: 'description' },
        ];

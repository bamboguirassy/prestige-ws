export const moyenPaiementColumns = [
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'Code', field: 'code', dataKey: 'code' },
            { header: 'Description', field: 'description', dataKey: 'description' },
        ];

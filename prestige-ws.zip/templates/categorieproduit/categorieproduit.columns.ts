export const categorieProduitColumns = [
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'Photo', field: 'photo', dataKey: 'photo' },
            { header: 'Description', field: 'description', dataKey: 'description' },
        ];

export const produitColumns = [
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'PrixMinimum', field: 'prixMinimum', dataKey: 'prixMinimum' },
            { header: 'PrixVariable', field: 'prixVariable', dataKey: 'prixVariable' },
            { header: 'Quantifiable', field: 'quantifiable', dataKey: 'quantifiable' },
            { header: 'QuantiteDisponible', field: 'quantiteDisponible', dataKey: 'quantiteDisponible' },
            { header: 'Expose', field: 'expose', dataKey: 'expose' },
            { header: 'Description', field: 'description', dataKey: 'description' },
            { header: 'Type', field: 'type', dataKey: 'type' },
        ];

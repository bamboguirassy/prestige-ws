export const reglementColumns = [
            { header: 'Montant', field: 'montant', dataKey: 'montant' },
            { header: 'Date', field: 'date', dataKey: 'date' },
            { header: 'MontantRestant', field: 'montantRestant', dataKey: 'montantRestant' },
            { header: 'Commande', field: 'commande', dataKey: 'commande' },
            { header: 'MontantDonne', field: 'montantDonne', dataKey: 'montantDonne' },
            { header: 'MontantRetourne', field: 'montantRetourne', dataKey: 'montantRetourne' },
        ];

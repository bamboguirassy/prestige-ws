export const caracteristiqueCategorieColumns = [
            { header: 'Nom', field: 'nom', dataKey: 'nom' },
            { header: 'IsColor', field: 'isColor', dataKey: 'isColor' },
        ];

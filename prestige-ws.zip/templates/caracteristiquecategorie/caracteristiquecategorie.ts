import { BamboObject } from 'src/app/shared/interfaces/bambo-object';

export class CaracteristiqueCategorie extends BamboObject {
    id: any;
                                nom: string;
                                        isColor: string;
                        
    constructor() {
        super();
    }
}
